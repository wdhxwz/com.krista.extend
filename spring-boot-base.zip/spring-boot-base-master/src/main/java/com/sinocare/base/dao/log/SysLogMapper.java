package com.sinocare.base.dao.log;

import com.sinocare.base.core.MyMapper;
import com.sinocare.base.po.log.SysLog;

public interface SysLogMapper extends MyMapper<SysLog> {
}