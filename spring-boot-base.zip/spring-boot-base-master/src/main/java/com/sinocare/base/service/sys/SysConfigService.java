package com.sinocare.base.service.sys;

import com.sinocare.base.core.Service;
import com.sinocare.base.po.sys.SysConfig;


/**
 * SysConfig
 *
 * @version 2018/06/27
 * @author jeikerxiao
 */
public interface SysConfigService extends Service<SysConfig> {

}
