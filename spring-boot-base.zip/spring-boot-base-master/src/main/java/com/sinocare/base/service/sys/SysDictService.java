package com.sinocare.base.service.sys;

import com.sinocare.base.core.Service;
import com.sinocare.base.po.sys.SysDict;


/**
 * SysDict
 *
 * @version 2018/07/06
 * @author jeikerxiao
 */
public interface SysDictService extends Service<SysDict> {

}
