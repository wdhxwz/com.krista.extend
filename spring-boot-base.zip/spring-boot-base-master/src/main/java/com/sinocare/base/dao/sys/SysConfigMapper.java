package com.sinocare.base.dao.sys;

import com.sinocare.base.core.MyMapper;
import com.sinocare.base.po.sys.SysConfig;

public interface SysConfigMapper extends MyMapper<SysConfig> {
}