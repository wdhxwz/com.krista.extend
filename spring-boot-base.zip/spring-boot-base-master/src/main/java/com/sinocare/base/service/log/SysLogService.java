package com.sinocare.base.service.log;

import com.sinocare.base.core.Service;
import com.sinocare.base.po.log.SysLog;


/**
 * SysLog
 *
 * @version 2018/06/27
 * @author jeikerxiao
 */
public interface SysLogService extends Service<SysLog> {

}
